function setup() {
  createCanvas(400, 400);
  background(20);
  angleMode(DEGREES);
  noLoop(); // Stop draw from continuously executing
}

function draw() {
  background(20);
  translate(width / 2, height / 2);
  
  for (let i = 0; i < 360; i += 15) {
    push();
    rotate(i);
    strokeWeight(2);
    stroke(map(i, 0, 360, 0, 255), 100, 255);
    line(0, 0, 150, 0);
    drawShapes(150, 0);
    pop();
  }
}

function drawShapes(x, y) {
  for (let j = 0; j < 10; j++) {
    let size = map(j, 0, 10, 5, 25);
    fill(map(j, 0, 10, 0, 255), 100, 200);
    noStroke();
    ellipse(x, y, size, size);
    x += size / 2;
    y += size / 2;
  }
}
