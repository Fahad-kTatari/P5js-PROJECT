function setup() {
  createCanvas(400, 400);
  noLoop();
}

function draw() {
  background(255);
  
  let values = [30, 70, 45, 85, 60];
  let colors = [color(255, 0, 0), color(0, 255, 0), color(0, 0, 255), color(200, 105, 0), color(0, 255, 295)];
  

  let total = values.reduce((acc, val) => acc + val, 0);
  

  let angleStart = 0;
  let diameter = min(width, height) * 0.75;
  
  
  for (let i = 0; i < values.length; i++) {
    let angleEnd = angleStart + (values[i] / total) * TWO_PI;
    fill(colors[i]);
    arc(width / 2, height / 2, diameter, diameter, angleStart, angleEnd, PIE);
    angleStart = angleEnd;
  }

  textAlign(CENTER, CENTER);
  let angleOffset = 0;
  for (let i = 0; i < values.length; i++) {
    let angleLabel = angleOffset + (values[i] / total) * PI;
    let x = width / 2 + cos(angleLabel) * (diameter / 2 + 20);
    let y = height / 2 + sin(angleLabel) * (diameter / 2 + 20);
    fill(0);
    text(labels[i], x, y);
    angleOffset += (values[i] / total) * TWO_PI;
  }
}