let song;
let fft;

function preload() {
  // Load an audio file
  song = loadSound('audio 24.mp3');
}

function setup() {
  createCanvas(800, 800);
  song.play();
  fft = new p5.FFT();
}

function draw() {
  background(0);

  let waveform = fft.waveform();
  translate(width / 2, height / 2);
  
  noFill();
  stroke(255);
  strokeWeight(2);
  
  for (let i = 0; i < waveform.length; i++) {
    let angle = map(i, 0, waveform.length, 0, TWO_PI);
    let radius = map(waveform[i], -1, 1, 100, 400);
    
    let x = radius * cos(angle);
    let y = radius * sin(angle);
    
    ellipse(x, y, 10, 10);
  }
}