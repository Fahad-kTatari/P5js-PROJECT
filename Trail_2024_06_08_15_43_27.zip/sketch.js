function setup() {
  createCanvas(400, 400);
  background(400);
}

function draw() {
  fill ("blue")
  square( mouseX, mouseY, 50);
  ellipse(mouseX, mouseY, 30);
fill('red')
rect(mouseX, mouseY, 10);
}