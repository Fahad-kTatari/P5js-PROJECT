function setup() {
  createCanvas(400, 400);
  background(255);
}

function draw() {
  background(255);
  translate(width / 2, height / 2);
  let numSquares = 10;
  let angleStep = TWO_PI / numSquares;
  for (let i = 0; i < numSquares; i++) {
    push();
    rotate(frameCount * 0.01 + i * angleStep);
    fill((i * 25) % 255, 150, 200);
    rect(0, 0, 100, 100);
    pop();
  }
}
