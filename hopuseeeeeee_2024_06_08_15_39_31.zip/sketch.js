function setup() {
  createCanvas(800, 600);
  background(135, 206, 235); // Sky blue background

  // Draw the sun
  fill(255, 223, 0);
  noStroke();
  ellipse(100, 100, 80, 80);

  // Draw the house
  fill(210, 105, 30); // Brick red color
  rect(300, 300, 200, 200); // House body
  
  fill(139, 69, 19); // Brown color for roof and door
  triangle(300, 300, 500, 300, 400, 200); // Roof
  rect(380, 400, 40, 100); // Door

  // Draw the windows
  fill(173, 216, 230); // Light blue for windows
  rect(320, 350, 50, 50); // Left window
  rect(430, 350, 50, 50); // Right window

  // Draw the tree
  fill(34, 139, 34); // Green for leaves
  ellipse(600, 350, 100, 100);
  ellipse(600, 300, 80, 80);
  
  fill(139, 69, 19); // Brown for trunk
  rect(580, 350, 40, 100);
}
