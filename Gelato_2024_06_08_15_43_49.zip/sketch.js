function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("blue");
  fill(255, 204, 100);
  
  let c = color("orange");
fill(c);
  circle(180,150,50);
  fill(255, 204, 0);
    let a = color("white");
fill(a);
  circle(200,180,50);
  fill(255, 204, 100);
    let b = color("black");
fill(b);
  circle(160,180,50);
  translate(107,120)

  let e = color("brown");
fill(e);
  
  triangle(30,75,75,160,115,75);
  // Draw sprinkles
  for (let i = 0; i <= 60; i += 30) {
    // Colorful sprinkles
    let sprinkleColor = color(random(255), random(255), random(255));
    fill(sprinkleColor);
    ellipse(400, 155 + i, 3, 3);
    ellipse(440, 145 + i, 3, 3);
    ellipse(360, 145 + i, 3, 3);
    ellipse(380, 135 + i, 3, 3);
    ellipse(420, 135 + i, 3, 3);
  }
  
}