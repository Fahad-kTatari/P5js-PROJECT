let trail = [];
let customMouse;

function preload() {
  // Load a custom mouse image
  customMouse = loadImage('images.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  noCursor(); // Hide the default mouse cursor
}

function draw() {
  background(255);
  
  // Push current mouse position to the trail array
  trail.push(createVector(mouseX, mouseY));
  
  // Remove the oldest points if the trail length exceeds a certain threshold
  if (trail.length > 50) {
    trail.splice(0, 1);
  }
  
  // Draw the trail
  for (let i = 0; i < trail.length; i++) {
    let pos = trail[i];
    image(customMouse, pos.x - 16, pos.y - 16, 32, 32); // Adjust size and position as needed
  }
}
