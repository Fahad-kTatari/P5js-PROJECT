var img;
function preload() {
  img = loadImage("sport.jpg");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image(img,0,0, img.height/2, img.width/3);
  noTint();
  image(img,200,200, img.height/2, img.width/3);
  tint("blue");
}