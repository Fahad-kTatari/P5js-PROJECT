function setup() {
  createCanvas(500, 400);
  noLoop();
}

function draw() {
  background(255);

  let values = [30, 70, 45, 85, 60];
  let colors = [color(155, 0, 0), color(100, 155, 0), color(255, 0, 155), color(150, 155, 180), color(0, 240, 285)];
  
  let margin = 20;
  let chartWidth = width - 2 * margin;
  let chartHeight = height - 2 * margin;
  let barWidth = chartWidth / values.length;
  let maxVal = max(values);
  
  for (let i = 0; i < values.length; i++) {
    let barHeight = map(values[i], 0, maxVal, 0, chartHeight);
    fill(colors[i]);
    rect(margin + i * barWidth, height - margin - barHeight, barWidth - 10, barHeight);
  }
  
  stroke(0);
  line(margin, margin, margin, height - margin); // y-axis
  line(margin, height - margin, width - margin, height - margin); // x-axis
}