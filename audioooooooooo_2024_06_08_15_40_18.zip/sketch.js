let song;
let fft;

function preload() {
  // Load an audio file
  song = loadSound('audioooo.mp3');
}

function setup() {
  createCanvas(800, 400);
  song.play();
  fft = new p5.FFT();
}

function draw() {
  background(0);

  let waveform = fft.waveform();
  noFill();
  beginShape();
  stroke(255);
  strokeWeight(2);
  for (let i = 0; i < waveform.length; i++) {
    let x = map(i, 0, waveform.length, 0, width);
    let y = map(waveform[i], -1, 1, height, 0);
    vertex(x, y);
  }
  endShape();
}