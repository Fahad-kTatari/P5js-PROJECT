function setup() {
  createCanvas(400, 400);
  noFill();
  background(255);
}

function draw() {
  background(255);
  translate(width / 2, height / 2);
  for (let i = 0; i < 20; i++) {
    stroke(map(i, 0, 20, 0, 255), 100, 150);
    ellipse(0, 0, i * 20, i * 20);
  }
}
