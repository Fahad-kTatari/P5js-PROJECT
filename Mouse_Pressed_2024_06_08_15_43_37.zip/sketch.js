function setup() {
  createCanvas(400, 400);
   background(220)
}

function draw() {
     fill(250,50);
     rect(mouseX,mouseY, 50);
     square(mouseX,mouseY, 65);
     square(mouseX,mouseY, 75);
  
  
}

function mousePressed() {
  background("blue")
  
  
}